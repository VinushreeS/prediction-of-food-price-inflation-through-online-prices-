#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Mar 17 14:52:26 2019

@author: deepak
"""

import numpy as np
import scipy as sp
import sklearn as sk
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.feature_selection import SelectPercentile, chi2
from sklearn.model_selection import cross_val_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC


from sklearn.feature_selection import SelectKBest

#data = np.read("Data_blore.csv")
blore_data = np.genfromtxt('Data_blore.csv', delimiter=',')
blore_data_tar = pd.read_csv("Data_blore.csv");

blore_X = blore_data[1:,:-1]
blore_y = blore_data[1:,-1:]

X_new = SelectKBest(chi2, k=8).fit_transform(blore_X, blore_y)
X_new.shape

clf = Pipeline([('anova', SelectPercentile(chi2)),
                ('scaler', StandardScaler()),
                ('svc', SVC(gamma="auto",kernel='linear'))])

score_means = list()
score_stds = list()
percentiles = (2,4,6,8,10,20,40,60,80,100)

for percentile in percentiles:
    clf.set_params(anova__percentile=percentile)
    this_scores = cross_val_score(clf, blore_X, blore_y, cv=6)
    score_means.append(this_scores.mean())
    score_stds.append(this_scores.std())

plt.errorbar(percentiles, score_means, np.array(score_stds))
plt.title('features selected based on optimal classification performance-blore')
plt.xticks(np.linspace(0, 100, 11, endpoint=True))
plt.xlabel('Percentile')
plt.ylabel('Accuracy Score')
plt.axis('tight')
plt.show()


blore_model = sk.linear_model.LogisticRegressionCV(penalty='l2',cv=6,max_iter=1000,multi_class='ovr')
blore_model.fit(blore_X,blore_y)
blore_fin_res  = blore_model.scores_
blore_fins_coef = blore_model.coef_





# for chennai

chen_data = np.genfromtxt('Data_chennai.csv', delimiter=',')
chen_data_tar = pd.read_csv("Data_chennai.csv");

chen_X = chen_data[1:,:-1]
chen_y = chen_data[1:,-1:]

X_new = SelectKBest(chi2, k=8).fit_transform(chen_X, chen_y)
X_new.shape

clf = Pipeline([('anova', SelectPercentile(chi2)),
                ('scaler', StandardScaler()),
                ('svc', SVC(gamma="auto"))])

score_means = list()
score_stds = list()
percentiles = (2,4,6,8,10,20,40,60,80,100)

for percentile in percentiles:
    clf.set_params(anova__percentile=percentile)
    this_scores = cross_val_score(clf, chen_X, chen_y, cv=5)
    score_means.append(this_scores.mean())
    score_stds.append(this_scores.std())

plt.errorbar(percentiles, score_means, np.array(score_stds))
plt.title('features selected based on optimal classification performance-chennai')
plt.xticks(np.linspace(0, 100, 11, endpoint=True))
plt.xlabel('Percentile')
plt.ylabel('Accuracy Score')
plt.axis('tight')
plt.show()


chen_model = sk.linear_model.LogisticRegressionCV(penalty='l2',cv=5,max_iter=1000,multi_class='ovr')
chen_model.fit(chen_X,chen_y)
chen_fin_res  = chen_model.scores_
chen_fins_coef = chen_model.coef_

# for delhi

del_data = np.genfromtxt('Data_delhi.csv', delimiter=',')
del_data_tar = pd.read_csv("Data_delhi.csv");

del_X = del_data[1:,:-1]
del_y = del_data[1:,-1:]

X_new = SelectKBest(chi2, k=8).fit_transform(del_X, del_y)
X_new.shape

clf = Pipeline([('anova', SelectPercentile(chi2)),
                ('scaler', StandardScaler()),
                ('svc', SVC(gamma="auto"))])

score_means = list()
score_stds = list()
percentiles = (2,4,6,8,10,20,40,60,80,100)

for percentile in percentiles:
    clf.set_params(anova__percentile=percentile)
    this_scores = cross_val_score(clf, del_X, del_y, cv=5)
    score_means.append(this_scores.mean())
    score_stds.append(this_scores.std())

plt.errorbar(percentiles, score_means, np.array(score_stds))
plt.title('features selected based on optimal classification performance-delhi')
plt.xticks(np.linspace(0, 100, 11, endpoint=True))
plt.xlabel('Percentile')
plt.ylabel('Accuracy Score')
plt.axis('tight')
plt.show()

del_model = sk.linear_model.LogisticRegressionCV(penalty='l2',cv=5,max_iter=1000,multi_class='ovr')
del_model.fit(del_X,del_y)
del_fin_res  = del_model.scores_
del_fins_coef = del_model.coef_

# for Mumbai

mb_data = np.genfromtxt('Data_mumbai.csv', delimiter=',')
mb_data_tar = pd.read_csv("Data_mumbai.csv");

mb_X = mb_data[1:,:-1]
mb_y = mb_data[1:,-1:]

X_new = SelectKBest(chi2, k=8).fit_transform(mb_X, mb_y)
X_new.shape

clf = Pipeline([('anova', SelectPercentile(chi2)),
                ('scaler', StandardScaler()),
                ('svc', SVC(gamma="auto"))])

score_means = list()
score_stds = list()
percentiles = (2,4,6,8,10,20,40,60,80,100)

for percentile in percentiles:
    clf.set_params(anova__percentile=percentile)
    this_scores = cross_val_score(clf, mb_X, mb_y, cv=5)
    score_means.append(this_scores.mean())
    score_stds.append(this_scores.std())

plt.errorbar(percentiles, score_means, np.array(score_stds))
plt.title('features selected based on optimal classification performance-mumbai')
plt.xticks(np.linspace(0, 100, 11, endpoint=True))
plt.xlabel('Percentile')
plt.ylabel('Accuracy Score')
plt.axis('tight')
plt.show()

mb_model = sk.linear_model.LogisticRegressionCV(penalty='l2',cv=5,max_iter=1000,multi_class='ovr')
mb_model.fit(mb_X,mb_y)
mb_fin_res  = mb_model.scores_
mb_fins_coef = mb_model.coef_

# for hyderabad

hyd_data = np.genfromtxt('Data_hyderabad.csv', delimiter=',')
hyd_data_tar = pd.read_csv("Data_hyderabad.csv");

hyd_X = hyd_data[1:,:-1]
hyd_y = hyd_data[1:,-1:]

X_new = SelectKBest(chi2, k=8).fit_transform(hyd_X, hyd_y)
X_new.shape

clf = Pipeline([('anova', SelectPercentile(chi2)),
                ('scaler', StandardScaler()),
                ('svc', SVC(gamma="auto"))])

score_means = list()
score_stds = list()
percentiles = (2,4,6,8,10,20,40,60,80,100)

for percentile in percentiles:
    clf.set_params(anova__percentile=percentile)
    this_scores = cross_val_score(clf, hyd_X, hyd_y, cv=5)
    score_means.append(this_scores.mean())
    score_stds.append(this_scores.std())

plt.errorbar(percentiles, score_means, np.array(score_stds))
plt.title('features selected based on optimal classification performance-hyderabad')
plt.xticks(np.linspace(0, 100, 11, endpoint=True))
plt.xlabel('Percentile')
plt.ylabel('Accuracy Score')
plt.axis('tight')
plt.show()

hyd_model = sk.linear_model.LogisticRegressionCV(penalty='l2',cv=5,max_iter=1000,multi_class='ovr')
hyd_model.fit(hyd_X,hyd_y)
hyd_fin_res  = hyd_model.scores_
hyd_fins_coef = hyd_model.coef_